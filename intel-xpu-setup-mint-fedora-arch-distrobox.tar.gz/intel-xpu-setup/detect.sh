#!/usr/bin/env bash
# Intel Arc XPU — Host Detection & Readiness Report
set -euo pipefail

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
BLUE='\033[0;34m'; BOLD='\033[1m'; DIM='\033[2m'; NC='\033[0m'

ok()   { echo -e "  ${GREEN}✔${NC}  $*"; }
warn() { echo -e "  ${YELLOW}⚠${NC}  $*"; }
fail() { echo -e "  ${RED}✘${NC}  $*"; }
info() { echo -e "  ${BLUE}→${NC}  $*"; }
hdr()  { echo -e "\n${BOLD}$*${NC}"; }

ISSUES=0
WARNINGS=0

hdr "══ Intel Arc XPU — Host Detection ══"

# ── Distro ────────────────────────────────────────────────────────────────────
hdr "Distro"
if [[ -f /etc/os-release ]]; then
    . /etc/os-release
    DISTRO_ID="${ID:-unknown}"
    DISTRO_NAME="${PRETTY_NAME:-${NAME:-unknown}}"
    DISTRO_VERSION="${VERSION_ID:-}"
    ok "${DISTRO_NAME}"

    case "$DISTRO_ID" in
        linuxmint|debian)
            info "LMDE/Debian detected — native install requires manual .deb packages"
            info "Distrobox (Ubuntu 25.10) is the recommended path"
            ;;
        fedora)
            info "Fedora detected — native install via dnf available"
            ;;
        arch|manjaro|endeavouros)
            info "Arch-based detected — native install via pacman available"
            ;;
        ubuntu)
            if [[ "${VERSION_ID:-0}" == "25.10" ]] || [[ "${VERSION_ID:-0}" == "24.04" ]]; then
                ok "Ubuntu ${VERSION_ID} — kobuk-team PPA supported natively"
            else
                warn "Ubuntu ${VERSION_ID} — kobuk-team PPA may not be available; consider 25.10"
                (( WARNINGS++ )) || true
            fi
            ;;
        *)
            warn "Unrecognised distro: ${DISTRO_ID} — Distrobox path recommended"
            (( WARNINGS++ )) || true
            ;;
    esac
else
    fail "/etc/os-release not found"
    (( ISSUES++ )) || true
fi

# ── Kernel ────────────────────────────────────────────────────────────────────
hdr "Kernel"
KERNEL=$(uname -r)
KMAJ=$(echo "$KERNEL" | cut -d. -f1)
KMIN=$(echo "$KERNEL" | cut -d. -f2)
echo -e "  ${DIM}${KERNEL}${NC}"

if   (( KMAJ > 6 )) || { (( KMAJ == 6 )) && (( KMIN >= 13 )); }; then
    ok "Kernel ${KERNEL} — full Lunar Lake xe support"
elif (( KMAJ == 6 )) && (( KMIN >= 10 )); then
    ok "Kernel ${KERNEL} — good xe support (6.13+ ideal for Lunar Lake)"
elif (( KMAJ == 6 )) && (( KMIN >= 8 )); then
    warn "Kernel ${KERNEL} — xe driver present but 6.10+ recommended"
    (( WARNINGS++ )) || true
else
    fail "Kernel ${KERNEL} — too old; xe driver requires 6.8+, 6.13+ for Lunar Lake"
    (( ISSUES++ )) || true
fi

# ── Intel GPU detection ───────────────────────────────────────────────────────
hdr "Intel GPU (lspci)"
if command -v lspci &>/dev/null; then
    GPUS=$(lspci | grep -iE "VGA|3D|Display" | grep -i intel || true)
    if [[ -n "$GPUS" ]]; then
        while IFS= read -r line; do ok "$line"; done <<< "$GPUS"
    else
        warn "No Intel GPU found via lspci"
        (( WARNINGS++ )) || true
    fi
else
    warn "lspci not available (install pciutils)"
    (( WARNINGS++ )) || true
fi

# ── Kernel modules ────────────────────────────────────────────────────────────
hdr "Kernel Modules"
if lsmod | grep -q "^xe "; then
    ok "xe module loaded (Battlemage/Lunar Lake — correct)"
elif lsmod | grep -q "^i915 "; then
    XE_PARAM=$(cat /sys/module/i915/parameters/force_probe 2>/dev/null || echo "")
    if [[ -n "$XE_PARAM" ]]; then
        warn "i915 loaded — Lunar Lake should use xe; check /etc/modprobe.d/"
    else
        ok "i915 loaded (older Arc — acceptable)"
    fi
    (( WARNINGS++ )) || true
else
    fail "Neither xe nor i915 module loaded"
    (( ISSUES++ )) || true
fi

# ── DRI / Accel device nodes ──────────────────────────────────────────────────
hdr "Device Nodes"
RENDER_NODES=$(ls /dev/dri/renderD* 2>/dev/null || true)
if [[ -n "$RENDER_NODES" ]]; then
    for n in $RENDER_NODES; do ok "$n"; done
else
    fail "/dev/dri/renderD* — no render nodes found"
    (( ISSUES++ )) || true
fi

ACCEL_NODES=$(ls /dev/accel/accel* 2>/dev/null || true)
if [[ -n "$ACCEL_NODES" ]]; then
    for n in $ACCEL_NODES; do ok "$n (accel/compute node)"; done
else
    warn "/dev/accel/accel* not found — may limit Level Zero compute access"
    info "This can appear after installing compute runtime and rebooting"
    (( WARNINGS++ )) || true
fi

# ── Group membership ──────────────────────────────────────────────────────────
hdr "User Groups"
CURRENT_USER="${SUDO_USER:-$USER}"
GROUPS_LIST=$(groups "$CURRENT_USER" 2>/dev/null || groups)

if echo "$GROUPS_LIST" | grep -qw render; then
    ok "User '${CURRENT_USER}' is in 'render' group"
else
    fail "User '${CURRENT_USER}' is NOT in 'render' group"
    info "Fix: sudo gpasswd -a ${CURRENT_USER} render  (then log out/in)"
    (( ISSUES++ )) || true
fi

if echo "$GROUPS_LIST" | grep -qw video; then
    ok "User '${CURRENT_USER}' is in 'video' group (bonus)"
else
    info "Optional: sudo gpasswd -a ${CURRENT_USER} video"
fi

# ── Compute runtime (OpenCL / Level Zero) ─────────────────────────────────────
hdr "Compute Runtime"
if command -v clinfo &>/dev/null; then
    CL_DEVS=$(clinfo --list 2>/dev/null | grep -c "Intel" || true)
    if (( CL_DEVS > 0 )); then
        ok "OpenCL: ${CL_DEVS} Intel device(s) visible via clinfo"
        clinfo --list 2>/dev/null | grep "Intel" | while IFS= read -r l; do
            info "  $l"
        done
    else
        warn "clinfo found but no Intel OpenCL devices listed"
        (( WARNINGS++ )) || true
    fi
else
    warn "clinfo not installed — cannot verify OpenCL"
    info "Install: apt install clinfo  /  dnf install clinfo  /  pacman -S clinfo"
    (( WARNINGS++ )) || true
fi

# Level Zero
if command -v sycl-ls &>/dev/null; then
    LZ=$(sycl-ls 2>/dev/null | grep -i "level_zero" || true)
    if [[ -n "$LZ" ]]; then
        ok "Level Zero device(s) visible via sycl-ls"
        echo "$LZ" | while IFS= read -r l; do info "  $l"; done
    else
        warn "sycl-ls found but no Level Zero devices listed"
        (( WARNINGS++ )) || true
    fi
else
    info "sycl-ls not available (part of Intel oneAPI basekit — optional)"
fi

# libze / compute-runtime package check
for lib in libze1 libze-intel-gpu1 intel-opencl-icd; do
    if dpkg -l "$lib" &>/dev/null 2>&1; then
        VER=$(dpkg -l "$lib" 2>/dev/null | awk '/^ii/{print $3}' | head -1)
        ok "${lib} ${VER} (apt)"
    elif rpm -q "$lib" &>/dev/null 2>&1; then
        ok "${lib} (rpm)"
    elif pacman -Qi "$lib" &>/dev/null 2>&1; then
        ok "${lib} (pacman)"
    fi
done

# ── Distrobox / container engine ──────────────────────────────────────────────
hdr "Distrobox & Container Engine"
if command -v distrobox &>/dev/null; then
    DB_VER=$(distrobox version 2>/dev/null | head -1 || echo "unknown")
    ok "distrobox: ${DB_VER}"
else
    warn "distrobox not installed"
    info "Install: curl -s https://raw.githubusercontent.com/89luca89/distrobox/main/install | sudo sh"
    (( WARNINGS++ )) || true
fi

if command -v podman &>/dev/null; then
    ok "podman $(podman --version | awk '{print $3}')"
elif command -v docker &>/dev/null; then
    ok "docker $(docker --version | awk '{print $3}' | tr -d ',')"
else
    fail "No container engine found (podman or docker required for distrobox)"
    (( ISSUES++ )) || true
fi

# ── uv ────────────────────────────────────────────────────────────────────────
hdr "Python / uv"
if command -v uv &>/dev/null; then
    ok "uv $(uv --version)"
else
    warn "uv not installed"
    info "Install: curl -LsSf https://astral.sh/uv/install.sh | sh"
    (( WARNINGS++ )) || true
fi

if command -v python3 &>/dev/null; then
    ok "python3 $(python3 --version 2>&1 | awk '{print $2}')"
fi

# ── Existing XPU container ────────────────────────────────────────────────────
hdr "Distrobox Containers"
if command -v distrobox &>/dev/null; then
    if distrobox list 2>/dev/null | grep -q "intel-xpu"; then
        ok "intel-xpu container already exists"
        info "Enter with: distrobox enter intel-xpu"
    else
        info "No intel-xpu container found — run setup-distrobox.sh to create one"
    fi
fi

# ── Summary ───────────────────────────────────────────────────────────────────
hdr "══ Summary ══"
if (( ISSUES == 0 && WARNINGS == 0 )); then
    echo -e "  ${GREEN}${BOLD}All checks passed — ready to install PyTorch XPU${NC}"
elif (( ISSUES == 0 )); then
    echo -e "  ${YELLOW}${BOLD}${WARNINGS} warning(s) — distrobox path will work around host limitations${NC}"
else
    echo -e "  ${RED}${BOLD}${ISSUES} issue(s), ${WARNINGS} warning(s) — review above before proceeding${NC}"
fi
echo

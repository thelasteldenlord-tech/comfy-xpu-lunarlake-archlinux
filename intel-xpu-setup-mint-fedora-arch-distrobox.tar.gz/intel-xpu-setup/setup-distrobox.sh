#!/usr/bin/env bash
# Intel Arc XPU — Distrobox Setup (Ubuntu 25.10)
# Works on any host: LMDE, Fedora, Arch, etc.
set -euo pipefail

BOLD='\033[1m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; NC='\033[0m'
step() { echo -e "\n${BOLD}▶ $*${NC}"; }
ok()   { echo -e "  ${GREEN}✔${NC}  $*"; }
warn() { echo -e "  ${YELLOW}⚠${NC}  $*"; }
die()  { echo -e "  ${RED}✘${NC}  $*" >&2; exit 1; }

CONTAINER_NAME="intel-xpu"
CONTAINER_IMAGE="ubuntu:25.10"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# ── 1. Verify host devices ────────────────────────────────────────────────────
step "Host device check"
[[ -e /dev/dri/renderD128 ]] || warn "/dev/dri/renderD128 not found — xe driver may not be loaded"
[[ -d /dev/accel ]] && ls /dev/accel/ | grep -q accel && \
    ok "/dev/accel devices present" || \
    warn "/dev/accel not found — will attempt container passthrough anyway"

# Render group check
if ! groups | grep -qw render; then
    warn "Current user not in 'render' group on host"
    warn "Add with: sudo gpasswd -a ${USER} render"
    warn "Continuing — distrobox will add render group inside the container"
fi

# ── 2. Container engine detection ────────────────────────────────────────────
step "Container engine"
if command -v podman &>/dev/null; then
    ENGINE="podman"
    ok "Using podman"
elif command -v docker &>/dev/null; then
    ENGINE="docker"
    ok "Using docker"
else
    die "Neither podman nor docker found. Install one first:
    LMDE/Debian : sudo apt install podman
    Fedora      : sudo dnf install podman
    Arch        : sudo pacman -S podman"
fi

# ── 3. Distrobox install / version check ─────────────────────────────────────
step "Distrobox"
if ! command -v distrobox &>/dev/null; then
    warn "distrobox not found — installing via upstream installer"
    curl -s https://raw.githubusercontent.com/89luca89/distrobox/main/install | \
        sudo sh -s -- --prefix /usr/local
    ok "distrobox installed"
fi

DB_VER=$(distrobox version 2>/dev/null | grep -oP '\d+\.\d+\.\d+' | head -1 || echo "0.0.0")
DB_MAJ=$(echo "$DB_VER" | cut -d. -f1)
DB_MIN=$(echo "$DB_VER" | cut -d. -f2)
ok "distrobox ${DB_VER}"

# --additional-flags (device passthrough) available in 1.7+
SUPPORTS_ADDL_FLAGS=false
if (( DB_MAJ > 1 )) || { (( DB_MAJ == 1 )) && (( DB_MIN >= 7 )); }; then
    SUPPORTS_ADDL_FLAGS=true
fi

# ── 4. Pull Ubuntu 25.10 image ────────────────────────────────────────────────
step "Container image: ${CONTAINER_IMAGE}"
${ENGINE} pull "${CONTAINER_IMAGE}" || die "Failed to pull ${CONTAINER_IMAGE}"
ok "Image ready"

# ── 5. Create (or reuse) container ────────────────────────────────────────────
step "Container: ${CONTAINER_NAME}"

if distrobox list 2>/dev/null | grep -qw "${CONTAINER_NAME}"; then
    warn "Container '${CONTAINER_NAME}' already exists — skipping creation"
    warn "To recreate: distrobox rm ${CONTAINER_NAME} --force"
else
    # Build device flags — always try to pass /dev/dri and /dev/accel
    DEVICE_FLAGS=""
    [[ -d /dev/dri   ]] && DEVICE_FLAGS="--device /dev/dri"
    [[ -d /dev/accel ]] && DEVICE_FLAGS="${DEVICE_FLAGS} --device /dev/accel"

    if $SUPPORTS_ADDL_FLAGS && [[ -n "$DEVICE_FLAGS" ]]; then
        distrobox create \
            --name "${CONTAINER_NAME}" \
            --image "${CONTAINER_IMAGE}" \
            --additional-flags "${DEVICE_FLAGS}" \
            --yes
    else
        # Older distrobox: devices inherited from host by default via /dev bind mount
        distrobox create \
            --name "${CONTAINER_NAME}" \
            --image "${CONTAINER_IMAGE}" \
            --yes
        [[ -z "$DEVICE_FLAGS" ]] || \
            warn "distrobox <1.7 — device flags not supported; devices passed via /dev bind"
    fi
    ok "Container created"
fi

# ── 6. Bootstrap the container (first run triggers OCI init) ─────────────────
step "Container bootstrap"
distrobox enter "${CONTAINER_NAME}" -- echo "Container ready" || \
    die "Failed to enter container"
ok "Bootstrap complete"

# ── 7. Run container-init.sh inside ──────────────────────────────────────────
step "Running container-init.sh inside ${CONTAINER_NAME}"
# Home dir is shared, so the script is already accessible inside
distrobox enter "${CONTAINER_NAME}" -- bash "${SCRIPT_DIR}/container-init.sh"

# ── 8. Final guidance ─────────────────────────────────────────────────────────
echo
echo -e "${GREEN}${BOLD}══ Setup complete ══${NC}"
echo
echo -e "Enter the container interactively:"
echo -e "  ${BOLD}distrobox enter ${CONTAINER_NAME}${NC}"
echo
echo -e "Activate the XPU venv inside:"
echo -e "  ${BOLD}source ~/.venvs/xpu/bin/activate${NC}"
echo
echo -e "Run a script from the host without entering:"
echo -e "  ${BOLD}distrobox run ${CONTAINER_NAME} -- ~/.venvs/xpu/bin/python your_script.py${NC}"
echo
echo -e "Export a binary to the host PATH:"
echo -e "  ${BOLD}distrobox-export --app ${CONTAINER_NAME} --bin ~/.venvs/xpu/bin/python${NC}"
echo
echo -e "Re-run just the verification:"
echo -e "  ${BOLD}distrobox enter ${CONTAINER_NAME} -- ~/.venvs/xpu/bin/python ~/intel-xpu-setup/verify-xpu.py${NC}"

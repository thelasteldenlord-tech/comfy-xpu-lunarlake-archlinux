#!/usr/bin/env python3
"""Intel Arc XPU verification — run with the XPU venv active."""
import sys
import time


def check(label: str, passed: bool, detail: str = "") -> bool:
    mark = "\033[32m✔\033[0m" if passed else "\033[31m✘\033[0m"
    print(f"  {mark}  {label}" + (f"  \033[2m{detail}\033[0m" if detail else ""))
    return passed


def main() -> int:
    print("\n\033[1m══ Intel Arc XPU Verification ══\033[0m\n")
    failures = 0

    # ── Import ──────────────────────────────────────────────────────────────
    try:
        import torch
    except ImportError:
        print("  \033[31m✘\033[0m  torch not importable — activate the XPU venv first")
        return 1

    check("torch import", True, torch.__version__)

    if not check("torch.xpu exists", hasattr(torch, "xpu")):
        print("\n  torch.xpu missing — this wheel is CPU-only or too old")
        return 1

    if not check("torch.xpu.is_available()", torch.xpu.is_available()):
        print("\n  XPU not available. Common causes:")
        print("    • Not in 'render' group  →  sudo gpasswd -a $USER render")
        print("    • intel-ocloc missing    →  re-run container-init.sh")
        print("    • /dev/accel not passed  →  recreate container with --device /dev/accel")
        failures += 1
        return failures

    n = torch.xpu.device_count()
    check("device count", n > 0, str(n))

    for i in range(n):
        name = torch.xpu.get_device_name(i)
        props = torch.xpu.get_device_properties(i)
        check(f"device[{i}]", True, name)
        print(f"       VRAM : {props.total_memory / 1e9:.1f} GB")

    # ── Compute ─────────────────────────────────────────────────────────────
    print()
    print("\033[1m  Compute tests\033[0m")
    try:
        sizes = [(512, 512), (2048, 2048)]
        for m, n_ in sizes:
            x = torch.randn(m, n_, device="xpu", dtype=torch.float16)
            y = torch.randn(m, n_, device="xpu", dtype=torch.float16)
            t0 = time.perf_counter()
            z = torch.mm(x, y)
            torch.xpu.synchronize()
            elapsed = (time.perf_counter() - t0) * 1000
            tflops = (2 * m * m * n_) / (elapsed / 1000) / 1e12
            check(f"matmul {m}×{n_} fp16", True, f"{elapsed:.1f} ms  {tflops:.2f} TFLOPS")
    except Exception as e:
        check("compute test", False, str(e))
        failures += 1

    # ── Basic neural net layer ───────────────────────────────────────────────
    try:
        import torch.nn as nn
        layer = nn.Linear(1024, 1024).to("xpu")
        inp = torch.randn(32, 1024, device="xpu")
        out = layer(inp)
        check("nn.Linear forward pass", out.shape == (32, 1024), str(out.shape))
    except Exception as e:
        check("nn.Linear forward pass", False, str(e))
        failures += 1

    # ── Summary ──────────────────────────────────────────────────────────────
    print()
    if failures == 0:
        print("\033[32m\033[1m  All checks passed — XPU is fully operational\033[0m")
    else:
        print(f"\033[31m\033[1m  {failures} check(s) failed\033[0m")
    print()
    return failures


if __name__ == "__main__":
    sys.exit(main())

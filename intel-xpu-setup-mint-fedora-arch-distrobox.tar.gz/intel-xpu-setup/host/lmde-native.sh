#!/usr/bin/env bash
# Intel Arc XPU — Native host setup for LMDE / Debian
# Manually installs compute-runtime .debs since no Ubuntu PPA is available.
set -euo pipefail

BOLD='\033[1m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; NC='\033[0m'
step() { echo -e "\n${BOLD}▶ $*${NC}"; }
ok()   { echo -e "  ${GREEN}✔${NC}  $*"; }
warn() { echo -e "  ${YELLOW}⚠${NC}  $*"; }
die()  { echo -e "  ${RED}✘${NC}  $*" >&2; exit 1; }

# Pinned versions — update by checking:
#   https://github.com/intel/compute-runtime/releases         (CR_VER)
#   https://github.com/intel/intel-graphics-compiler/releases (IGC_VER)
#   https://github.com/intel/gmmlib/releases                  (GMM_VER)
# Always match the IGC version listed in the compute-runtime release notes.
CR_VER="26.18.38308.1"
IGC_VER="2.34.4"
GMM_VER="22.10.0"

WORK_DIR=$(mktemp -d -t intel-compute-XXXX)
trap 'rm -rf "$WORK_DIR"' EXIT

# ── 1. System dependencies ────────────────────────────────────────────────────
step "System dependencies"
sudo apt-get update -qq
sudo apt-get install -y -qq \
    ocl-icd-libopencl1 \
    libze1 \
    libze-dev \
    clinfo \
    wget \
    curl

# libze1 from Debian backports if not in main
if ! dpkg -l libze1 &>/dev/null 2>&1; then
    warn "libze1 not found in main repos — trying backports"
    echo "deb http://deb.debian.org/debian bookworm-backports main contrib non-free" | \
        sudo tee /etc/apt/sources.list.d/backports.list
    sudo apt-get update -qq
    sudo apt-get install -y -t bookworm-backports libze1 libze-dev
fi

ok "System deps ready"

# ── 2. Intel Graphics Compiler (IGC) ─────────────────────────────────────────
step "Intel Graphics Compiler ${IGC_VER}"
cd "$WORK_DIR"
IGC_BASE="https://github.com/intel/intel-graphics-compiler/releases/download/v${IGC_VER}"

wget -q --show-progress \
    "${IGC_BASE}/intel-igc-core_${IGC_VER}_amd64.deb" \
    "${IGC_BASE}/intel-igc-opencl_${IGC_VER}_amd64.deb" \
    "${IGC_BASE}/libigdfcl1_${IGC_VER}_amd64.deb" \
    "${IGC_BASE}/libigc2_${IGC_VER}_amd64.deb"

sudo dpkg -i \
    "intel-igc-core_${IGC_VER}_amd64.deb" \
    "intel-igc-opencl_${IGC_VER}_amd64.deb" \
    "libigdfcl1_${IGC_VER}_amd64.deb" \
    "libigc2_${IGC_VER}_amd64.deb" 2>&1 | grep -v "^(Reading\|Selecting\|Preparing\|Unpacking\|Setting)"

sudo apt-get install -f -y -qq   # resolve any dependency gaps
ok "IGC ${IGC_VER} installed"

# ── 3. Intel Compute Runtime ──────────────────────────────────────────────────
step "Intel Compute Runtime ${CR_VER}"
CR_BASE="https://github.com/intel/compute-runtime/releases/download/${CR_VER}"

wget -q --show-progress \
    "${CR_BASE}/libigdgmm12_${GMM_VER}_amd64.deb" \
    "${CR_BASE}/intel-opencl-icd_${CR_VER}_amd64.deb" \
    "${CR_BASE}/intel-ocloc_${CR_VER}_amd64.deb" \
    "${CR_BASE}/libze-intel-gpu1_${CR_VER}_amd64.deb"

sudo dpkg -i \
    "libigdgmm12_${GMM_VER}_amd64.deb" \
    "libze-intel-gpu1_${CR_VER}_amd64.deb" \
    "intel-opencl-icd_${CR_VER}_amd64.deb" \
    "intel-ocloc_${CR_VER}_amd64.deb" 2>&1 | grep -v "^(Reading\|Selecting\|Preparing\|Unpacking\|Setting)"

sudo apt-get install -f -y -qq
ok "Compute Runtime ${CR_VER} installed"

# ── 4. Render group ───────────────────────────────────────────────────────────
step "Render group"
CURRENT_USER="${SUDO_USER:-$USER}"
if ! id -nG "$CURRENT_USER" | grep -qw render; then
    sudo gpasswd -a "$CURRENT_USER" render
    warn "Added to 'render' — log out and back in (or run: newgrp render)"
else
    ok "Already in 'render' group"
fi

# ── 5. Verify ─────────────────────────────────────────────────────────────────
step "Verification"
echo -n "  OpenCL devices: "
clinfo --list 2>/dev/null | grep -c "Intel" && \
    clinfo --list 2>/dev/null | grep "Intel" || \
    warn "No Intel OpenCL device found yet — try logging out/in or rebooting"

echo
echo -e "${GREEN}${BOLD}Native LMDE setup complete.${NC}"
warn "If clinfo shows no devices, reboot and re-run detect.sh"
echo
echo -e "Next: install PyTorch XPU with uv:"
echo -e "  uv venv --python 3.12 ~/.venvs/xpu"
echo -e "  source ~/.venvs/xpu/bin/activate"
echo -e "  uv pip install torch==2.7.1+xpu torchvision==0.22.1+xpu torchaudio==2.7.1+xpu \\"
echo -e "    intel-cmplr-lib-rt intel-cmplr-lib-ur intel-cmplr-lic-rt intel-sycl-rt \\"
echo -e "    pytorch-triton-xpu tcmlib umf intel-pti \\"
echo -e "    --index-url https://download.pytorch.org/whl/xpu \\"
echo -e "    --extra-index-url https://pypi.org/simple"

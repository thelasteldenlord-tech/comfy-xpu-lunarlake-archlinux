#!/usr/bin/env bash
# Intel Arc XPU — Native host setup for Fedora 40/41/42+
# All packages available in standard Fedora repos — no COPR needed.
set -euo pipefail

BOLD='\033[1m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; NC='\033[0m'
step() { echo -e "\n${BOLD}▶ $*${NC}"; }
ok()   { echo -e "  ${GREEN}✔${NC}  $*"; }
warn() { echo -e "  ${YELLOW}⚠${NC}  $*"; }

# ── 1. Compute runtime & Level Zero ───────────────────────────────────────────
step "Intel compute runtime & Level Zero"
sudo dnf install -y \
    intel-compute-runtime \
    intel-ocloc \
    intel-gsc \
    intel-gmmlib \
    intel-igc-core \
    intel-igc-cm \
    intel-igc-opencl \
    intel-opencl \
    level-zero \
    intel-level-zero-gpu \
    intel-metrics-discovery \
    intel-metrics-library \
    clinfo

ok "Compute runtime installed"

# ── 2. Media stack (optional but useful for encode/decode workloads) ──────────
step "Media stack"
sudo dnf install -y \
    intel-media-driver \
    libmfx \
    libmfxgen1 \
    libvpl \
    libva \
    libva-utils || warn "Some media packages unavailable — skipping"

ok "Media stack done"

# ── 3. Render group ───────────────────────────────────────────────────────────
step "Render group"
CURRENT_USER="${SUDO_USER:-$USER}"
if ! id -nG "$CURRENT_USER" | grep -qw render; then
    sudo gpasswd -a "$CURRENT_USER" render
    warn "Added to 'render' — log out and back in"
else
    ok "Already in 'render' group"
fi

# ── 4. Verify ─────────────────────────────────────────────────────────────────
step "Verification"
echo "  OpenCL devices:"
clinfo --list 2>/dev/null | grep -i intel || warn "No Intel OpenCL device visible yet"

echo
echo -e "${GREEN}${BOLD}Native Fedora setup complete.${NC}"
echo
echo -e "Next: install PyTorch XPU with uv:"
echo -e "  uv venv --python 3.12 ~/.venvs/xpu"
echo -e "  source ~/.venvs/xpu/bin/activate"
echo -e "  uv pip install torch==2.7.1+xpu torchvision==0.22.1+xpu torchaudio==2.7.1+xpu \\"
echo -e "    intel-cmplr-lib-rt intel-cmplr-lib-ur intel-cmplr-lic-rt intel-sycl-rt \\"
echo -e "    pytorch-triton-xpu tcmlib umf intel-pti \\"
echo -e "    --index-url https://download.pytorch.org/whl/xpu \\"
echo -e "    --extra-index-url https://pypi.org/simple"

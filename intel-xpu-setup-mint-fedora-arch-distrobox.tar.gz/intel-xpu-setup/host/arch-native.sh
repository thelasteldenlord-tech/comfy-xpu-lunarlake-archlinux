#!/usr/bin/env bash
# Intel Arc XPU — Native host setup for Arch Linux / Manjaro / EndeavourOS
# All packages available in the 'extra' repo — no AUR needed.
set -euo pipefail

BOLD='\033[1m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; NC='\033[0m'
step() { echo -e "\n${BOLD}▶ $*${NC}"; }
ok()   { echo -e "  ${GREEN}✔${NC}  $*"; }
warn() { echo -e "  ${YELLOW}⚠${NC}  $*"; }

# ── 1. Detect AUR helper (optional, for -bin packages if needed) ──────────────
AUR_HELPER=""
for h in paru yay; do
    command -v "$h" &>/dev/null && AUR_HELPER="$h" && break
done

# ── 2. Core compute runtime (all in extra) ────────────────────────────────────
step "Intel compute runtime & Level Zero"
sudo pacman -Sy --needed --noconfirm \
    intel-compute-runtime \
    intel-graphics-compiler \
    intel-gmmlib \
    intel-ocloc \
    level-zero-headers \
    level-zero-loader \
    opencl-intel \
    clinfo \
    intel-gpu-tools

ok "Compute runtime installed"

# ── 3. Media stack ────────────────────────────────────────────────────────────
step "Media stack"
sudo pacman -S --needed --noconfirm \
    intel-media-driver \
    libva-intel-driver \
    libvpl \
    libva-utils || warn "Some media packages unavailable"

ok "Media stack done"

# ── 4. Render group ───────────────────────────────────────────────────────────
step "Render group"
CURRENT_USER="${SUDO_USER:-$USER}"
if ! id -nG "$CURRENT_USER" | grep -qw render; then
    sudo gpasswd -a "$CURRENT_USER" render
    warn "Added to 'render' — log out and back in"
else
    ok "Already in 'render' group"
fi

# ── 5. intel_gpu_top (monitoring, like nvidia-smi) ───────────────────────────
step "GPU monitoring tool"
if ! command -v intel_gpu_top &>/dev/null; then
    sudo pacman -S --needed --noconfirm igt-gpu-tools && ok "intel_gpu_top available"
else
    ok "intel_gpu_top already installed"
fi

# ── 6. Verify ─────────────────────────────────────────────────────────────────
step "Verification"
echo "  OpenCL devices:"
clinfo --list 2>/dev/null | grep -i intel || warn "No Intel OpenCL device visible yet"

if command -v sycl-ls &>/dev/null; then
    echo "  SYCL/Level Zero devices:"
    sycl-ls 2>/dev/null | grep -i "level_zero" || true
fi

echo
echo -e "${GREEN}${BOLD}Native Arch setup complete.${NC}"
echo
echo -e "Monitor GPU utilisation:"
echo -e "  ${BOLD}sudo intel_gpu_top${NC}"
echo
echo -e "Next: install PyTorch XPU with uv:"
echo -e "  uv venv --python 3.12 ~/.venvs/xpu"
echo -e "  source ~/.venvs/xpu/bin/activate"
echo -e "  uv pip install torch==2.7.1+xpu torchvision==0.22.1+xpu torchaudio==2.7.1+xpu \\"
echo -e "    intel-cmplr-lib-rt intel-cmplr-lib-ur intel-cmplr-lic-rt intel-sycl-rt \\"
echo -e "    pytorch-triton-xpu tcmlib umf intel-pti \\"
echo -e "    --index-url https://download.pytorch.org/whl/xpu \\"
echo -e "    --extra-index-url https://pypi.org/simple"

#!/usr/bin/env bash
# Runs INSIDE the Ubuntu 25.10 distrobox container.
# Called automatically by setup-distrobox.sh — can also be re-run manually.
set -euo pipefail

BOLD='\033[1m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; NC='\033[0m'
step() { echo -e "\n${BOLD}▶ $*${NC}"; }
ok()   { echo -e "  ${GREEN}✔${NC}  $*"; }
warn() { echo -e "  ${YELLOW}⚠${NC}  $*"; }

UV_BIN="${HOME}/.local/bin/uv"
XPU_VENV="${HOME}/.venvs/xpu"

# ── 1. System update ──────────────────────────────────────────────────────────
step "System update"
sudo apt-get update -qq

# ── 2. kobuk-team Intel Graphics PPA ─────────────────────────────────────────
step "Intel Graphics PPA (kobuk-team)"
if ! grep -rq "kobuk-team" /etc/apt/sources.list.d/ 2>/dev/null; then
    sudo apt-get install -y -qq software-properties-common
    sudo add-apt-repository -y ppa:kobuk-team/intel-graphics
    sudo apt-get update -qq
    ok "PPA added"
else
    ok "PPA already present"
fi

# ── 3. Compute runtime packages ───────────────────────────────────────────────
step "Intel compute runtime & Level Zero"
sudo apt-get install -y -qq \
    libze-intel-gpu1 \
    libze1 \
    libze-dev \
    intel-opencl-icd \
    intel-ocloc \
    intel-gsc \
    intel-metrics-discovery \
    clinfo \
    ocl-icd-libopencl1

ok "Compute runtime installed"

# ── 4. Render group ───────────────────────────────────────────────────────────
step "Render group membership"
CURRENT_USER="${USER}"
if ! groups | grep -qw render; then
    sudo gpasswd -a "${CURRENT_USER}" render
    warn "Added to 'render' group — effective after container restart"
    warn "Run: distrobox stop intel-xpu && distrobox enter intel-xpu"
else
    ok "Already in 'render' group"
fi

# ── 5. Verify compute devices ─────────────────────────────────────────────────
step "Device verification"
echo -e "  /dev/dri nodes:"
ls /dev/dri/ 2>/dev/null | while read -r n; do echo "    /dev/dri/${n}"; done || \
    warn "/dev/dri not visible — check distrobox device passthrough"

echo -e "  /dev/accel nodes:"
ls /dev/accel/ 2>/dev/null | while read -r n; do echo "    /dev/accel/${n}"; done || \
    warn "/dev/accel not visible — may need --additional-flags on container creation"

echo -e "  OpenCL devices:"
clinfo --list 2>/dev/null || warn "clinfo returned no devices (compute runtime may need restart)"

# ── 6. uv ─────────────────────────────────────────────────────────────────────
step "uv installation"
if [[ -x "$UV_BIN" ]]; then
    ok "uv already installed: $(${UV_BIN} --version)"
else
    curl -LsSf https://astral.sh/uv/install.sh | sh
    ok "uv installed: $(${UV_BIN} --version)"
fi

# Ensure uv is on PATH for this session
export PATH="${HOME}/.local/bin:${PATH}"

# ── 7. Python XPU virtual environment ─────────────────────────────────────────
step "Python XPU venv at ${XPU_VENV}"
if [[ -d "${XPU_VENV}" ]]; then
    warn "venv already exists — reinstalling PyTorch XPU"
    rm -rf "${XPU_VENV}"
fi

uv venv --python 3.12 "${XPU_VENV}"
ok "venv created"

# ── 8. PyTorch 2.7.1+xpu ──────────────────────────────────────────────────────
step "PyTorch 2.7.1+xpu install (this takes a few minutes)"

# Explicit package list avoids resolver falling back to CPU wheels.
# intel-cmplr-* and intel-sycl-rt ship the SYCL runtime bundled in the wheel;
# they're what makes torch.xpu.is_available() return True on non-oneAPI hosts.
uv pip install \
    --python "${XPU_VENV}" \
    --index-url  https://download.pytorch.org/whl/xpu \
    --extra-index-url https://pypi.org/simple \
    torch==2.7.1+xpu \
    torchvision==0.22.1+xpu \
    torchaudio==2.7.1+xpu \
    intel-cmplr-lib-rt \
    intel-cmplr-lib-ur \
    intel-cmplr-lic-rt \
    intel-sycl-rt \
    pytorch-triton-xpu \
    tcmlib \
    umf \
    intel-pti

ok "PyTorch XPU installed"

# ── 9. Write uv.toml for future use in this venv ─────────────────────────────
step "Writing uv.toml for XPU index"
cat > "${XPU_VENV}/../uv.toml" <<'UVTOML'
# Drop this file in any project directory to get XPU-aware uv resolution.
# Usage: uv pip install "torch==2.7.1+xpu" --index pytorch-xpu
[[index]]
name     = "pytorch-xpu"
url      = "https://download.pytorch.org/whl/xpu"
priority = "explicit"

[[index]]
name     = "pypi"
url      = "https://pypi.org/simple"
priority = "primary"
UVTOML
ok "uv.toml written to $(realpath "${XPU_VENV}/../uv.toml")"

# ── 10. Run verification script ───────────────────────────────────────────────
step "XPU verification"
VERIFY_SCRIPT="${HOME}/intel-xpu-setup/verify-xpu.py"
if [[ -f "$VERIFY_SCRIPT" ]]; then
    "${XPU_VENV}/bin/python" "$VERIFY_SCRIPT"
else
    # Inline fallback
    "${XPU_VENV}/bin/python" - <<'PYEOF'
import torch, sys
print(f"PyTorch      : {torch.__version__}")
print(f"XPU available: {torch.xpu.is_available()}")
if torch.xpu.is_available():
    print(f"Device count : {torch.xpu.device_count()}")
    print(f"Device name  : {torch.xpu.get_device_name(0)}")
    x = torch.randn(512, 512, device='xpu')
    y = torch.randn(512, 512, device='xpu')
    z = torch.mm(x, y)
    print(f"matmul OK on : {z.device}")
else:
    print("XPU not available — check render group and compute runtime", file=sys.stderr)
    sys.exit(1)
PYEOF
fi

echo
echo -e "${GREEN}${BOLD}Setup complete.${NC}"
echo -e "Activate the venv inside the container with:"
echo -e "  source ${XPU_VENV}/bin/activate"
echo
echo -e "From the host, run a one-off command with:"
echo -e "  distrobox run intel-xpu -- ${XPU_VENV}/bin/python your_script.py"
